﻿using System;
using System.Collections.Generic;

namespace program1
{
    class Program
    {
        static void Main()
        {
            string[] input  = System.IO.File.ReadAllLines(@"MachineInstructions.txt");
            string[] output = decodeMips(input);
            System.IO.File.WriteAllLines(@"Program1.txt", output);
        }

        static public string[] decodeMips(string[] program)
        {
            // Only Supports instructions present in example.
            Dictionary<string,string> opCode_inst = new Dictionary<string,string>();
            opCode_inst.Add("001000", "{0}\taddi   {1}, {2}, {3}");
            opCode_inst.Add("001101", "{0}\tori    {1}, {2}, {3}");
            opCode_inst.Add("000100", "{0}\tbeq    {1}, {2}, {3}");
            opCode_inst.Add("101011", "{0}\tsw     {1}, {2}({3})");
            opCode_inst.Add("100011", "{0}\tlw     {1}, {2}({3})");
            opCode_inst.Add("001111", "{0}\tlui    {1}, {2}");
            opCode_inst.Add("000010", "{0}\tj      {1}");
            opCode_inst.Add("000000", "{0}\tsyscall");
            
            

            // Only supports registers present in example.
            Dictionary<string,string> reg_num = new Dictionary<string,string>();
            reg_num.Add("00000", "$0");
            reg_num.Add("00001", "$at");
            reg_num.Add("00010", "$v0");
            reg_num.Add("01000", "$t0");
            reg_num.Add("01001", "$t1");
            reg_num.Add("01010", "$t2");
            reg_num.Add("01011", "$t3");

            string[] decoded = new string[program.Length];
        
            for(int i = 0; i < program.Length; i++)
            {
                // Split address and instruction,convert instruction to binary string, and
                // fix it to length 32.
                string[]   inst = program[i].Split('\t');
                string     addr = inst[0];
                string instCode = Convert.ToString(Convert.ToInt32(inst[1],16),2).PadLeft(32,'0');

                string   func   = instCode.Substring(0,6);
                string    rs;     
                string    rt;     
                int      imm;    
                string jaddr;

                switch(func)
                {
                    case "000010": // jump
                        jaddr = "0x" + (4*Convert.ToInt32(instCode.Substring(6,26),2)).ToString("X").PadLeft(8,'0');
                        decoded[i] = String.Format(opCode_inst[func], addr, jaddr);
                        break;
                    case "001111": // lui
                        rt  = instCode.Substring(11,5);
                        rs  = instCode.Substring(6,5);
                        imm = Convert.ToInt32(instCode.Substring(16,16),2);

                        decoded[i] = String.Format(opCode_inst["001111"], addr, reg_num[rt], imm);
                        break;
                    case "000000": // syscall
                        decoded[i] = String.Format(opCode_inst[func], addr);
                        break;
                    default: // standard I instruction
                        rs  = instCode.Substring(6,5);
                        rt  = instCode.Substring(11,5);
                        imm = Convert.ToInt32(instCode.Substring(16,16),2);
                        if(func == "101011" || func == "100011") // lw or sw
                        {
                             decoded[i] = String.Format(opCode_inst[func], addr, reg_num[rt], imm, reg_num[rs]);
                        }
                        else decoded[i] = String.Format(opCode_inst[func], addr, reg_num[rt], reg_num[rs], imm);
                        break;        
                }
            }
            return decoded;
        }
    }
}
